﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using NAudio.Wave;

namespace st10456656_POE_PART_1
{
    class CybersecurityChatbot
    {

        static void Main(string[] args)
        {
            //Code to play audio
            try
            {
                // Load and play the WAV file
                SoundPlayer GreetingIntro = new SoundPlayer("Greeting.wav"); // Make sure this file exists in the same folder as the EXE
                GreetingIntro.PlaySync(); // Waits until sound is done playing

            }
            catch (Exception ex)
            {
                Console.WriteLine("Error playing greeting: " + ex.Message);
            }


            // Initialize console settings for better visual presentation
            Console.Title = "Cybersecurity Awareness Bot";
            Console.ForegroundColor = ConsoleColor.Cyan;

            // Display ASCII art logo at startup
            // Reference: https://www.asciiart.eu/computers
            DisplayLogo();

            // Get user's name and provide personalized greeting
            // Reference: https://docs.microsoft.com/en-us/dotnet/api/system.console.readline
            Console.Write("\nPlease enter your name: ");
            string userName = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(userName))
                userName = "User"; // Default name if input is empty

            // Display welcome message with decorative borders
            DisplayWelcomeMessage(userName);

            // Main chatbot loop
            while (true)
            {
                // Prompt user for input with colored text
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("\n[You]: ");
                Console.ForegroundColor = ConsoleColor.White;
                string input = Console.ReadLine()?.ToLower().Trim();

                // Input validation
                // Reference: https://docs.microsoft.com/en-us/dotnet/csharp/programming-guide/strings/
                if (string.IsNullOrWhiteSpace(input))
                {
                    DisplayTypingEffect("I didn't quite understand that. Could you rephrase?");
                    continue;
                }

                // Exit condition
                if (input == "exit" || input == "quit")
                {
                    DisplayTypingEffect("Thank you for using the Cybersecurity Awareness Bot. Stay safe online!");
                    break;
                }

                // Process user input and provide responses
                string response = GetResponse(input, userName);
                DisplayTypingEffect(response);
            }

            // Reset console color before exit
            Console.ResetColor();
        }

        static void DisplayLogo()
        {
            // Simple ASCII art for cybersecurity theme
            // Reference: https://ascii.co.uk/art/security
            string logo = @"
   __ _     _   __ _  ___ __  
  / _| |   |_ | / _| |/ / ___|  _ \ 
 | |   | |    | | | |   | ' /|  _| | | | |
 | |_| |_ | | | |_| . \| |_| |_| |
  \_|_|_| \_||\\__|_/
  Cybersecurity Awareness Bot
=========================================";
            Console.WriteLine(logo);
        }

        static void DisplayWelcomeMessage(string userName)
        {
            // Welcome message with borders for visual appeal
            // Reference: https://docs.microsoft.com/en-us/dotnet/api/system.console.writeline
            string welcome = $@"=========================================
Welcome, {userName}, to the Cybersecurity Awareness Bot!
I'm here to help you learn about staying safe online.
You can ask about:
- Password safety
- Phishing scams
- Safe browsing
Type 'exit' to quit.
=========================================";
            DisplayTypingEffect(welcome);
        }

        static void DisplayTypingEffect(string message)
        {
            // Simulate typing effect for conversational feel
            // Reference: https://docs.microsoft.com/en-us/dotnet/api/system.threading.thread.sleep
            foreach (char c in message)
            {
                Console.Write(c);
                Thread.Sleep(20); // Delay for typing effect
            }
            Console.WriteLine();
        }

        static string GetResponse(string input, string userName)
        {
            // Basic response system for cybersecurity questions
            // Reference: https://www.sans.org/security-awareness-training/
            if (input.Contains("how are you"))
                return "I'm doing great, thanks for asking! How about you, are you staying safe online?";
            else if (input.Contains("purpose") || input.Contains("what do you do"))
                return "I'm here to educate you on cybersecurity, like avoiding phishing scams and creating strong passwords!";
            else if (input.Contains("password"))
                return "Use strong passwords with at least 12 characters, including letters, numbers, and symbols. Never reuse passwords across sites!";
            else if (input.Contains("phishing"))
                return "Phishing emails trick you into sharing personal info. Look for suspicious sender addresses and avoid clicking unknown links.";
            else if (input.Contains("browsing") || input.Contains("safe browsing"))
                return "Stick to HTTPS websites, keep your browser updated, and avoid downloading files from untrusted sources.";
            else if (input.Contains("what can i ask"))
                return "You can ask about password safety, phishing scams, safe browsing, or even how I'm doing!";
            else
                return "I didn't quite understand that. Try asking about password safety, phishing, or safe browsing!";
        }
    }
}
